﻿
$(function () {
	console.log("ready!");

	var movies = {};

	getTrendingMovies("titles?limit=6&page=2");

});

async function getTrendingMovies(uri) {

	movies = await getMoviesByTitle(uri);
	console.log('returned movies response from the API: ' + movies);
	await showTrendingMovies();

	return;
}

async function showTrendingMovies() {

	console.log('Trending videos count: ' + movies);
	//alert('Trending videos count: ' + movies);

	movies = JSON.parse(movies);
	var count = (movies.entries) ?? 0;

	$("#movie-tiles").empty();
	if (count == 0) {
		$("#movie-tiles").append('No Trending Movies were found!');

		console.log('Trending Movies were found!');
		return;
	}

	for (var i = 0; i < 6; i++) {

		var movieTiles = "";

		var image = (movies.results[i].primaryImage == null) ? "../Images/No-image.jpg" : movies.results[i].primaryImage.url;
		
			movieTiles = '<a class="movie" href="#"><img ' +
				'src = "' + image + '" ' +
				'class="w-100 shadow-1-strong rounded mb-4" ' +
				'alt = "Movie" /></a>';

			$("#movie-tiles").append(movieTiles);
		
	}
	
}

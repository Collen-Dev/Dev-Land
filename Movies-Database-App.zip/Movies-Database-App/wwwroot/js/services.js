﻿// This file contains API service calls:

const serviceUrl = 'https://localhost:7272/Movies/GetMoviesAndSeries';

const options = {
		method: "GET",
		mode: "cors",
	credentials: "same-origin"
};

async function getMoviesByTitle() {

	var jsonObj = {};
	const url = serviceUrl; 

	var result = await fetch(url , options)
		.then((response) => {
			return response.json().then((data) => {

				return data;
			}).catch((err) => {
				console.log(err);
			})
		});

	return JSON.stringify(result);
}

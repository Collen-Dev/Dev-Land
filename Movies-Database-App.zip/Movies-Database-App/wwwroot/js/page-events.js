﻿
$(function () {
	console.log("ready!");

    $('#sign-in').click(function (event) {

        alert('Clicked: ' + event.target);

        window.location.href = "../moviegallery";
    });


    $('.movie').click(function (event) {

        event.preventDefault();
        alert('Clicked: movie');

    });

});

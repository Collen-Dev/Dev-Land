using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MoviesRentalApp.Pages
{
    public class SignInModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MoviesRentalApp.Pages
{
    public class MovieGalleryModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
